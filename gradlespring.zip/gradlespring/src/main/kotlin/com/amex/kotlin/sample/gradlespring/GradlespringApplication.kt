package com.amex.kotlin.sample.gradlespring

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class GradlespringApplication

fun main(args: Array<String>) {
	runApplication<GradlespringApplication>(*args)
}

package com.amex.kotlin.sample.gradlespring

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class GradlespringApplicationTests {

	@Test
	fun contextLoads() {
	}

}

package com.google.training.appdev.console

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ConsoleApplicationTests {

	@Test
	fun contextLoads() {
	}

}

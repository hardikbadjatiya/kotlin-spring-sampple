/*
 * Copyright 2018 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.training.appdev.console

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport
import com.google.api.client.http.HttpTransport
import com.google.api.client.json.JsonFactory
import com.google.api.client.json.jackson2.JacksonFactory
import com.google.api.services.compute.Compute
import com.google.api.services.compute.ComputeScopes
import com.google.api.services.compute.model.InstanceList
import java.io.IOException
import java.util.*

object ConsoleApp {
    private const val APPLICATION_NAME = ""

    /** Set PROJECT_ID to your Project ID from the Overview pane in the Developers console.  */
    private val PROJECT_ID = System.getenv("GCLOUD_PROJECT")

    /** Set Compute Engine zone.  */
    private const val ZONE_NAME = "us-central1-f"

    /** Global instance of the HTTP transport.  */
    private var httpTransport: HttpTransport? = null

    /** Global instance of the JSON factory.  */
    private val JSON_FACTORY: JsonFactory = JacksonFactory.getDefaultInstance()
    @kotlin.jvm.JvmStatic
    fun main(args: Array<String>) {
        try {
            httpTransport = GoogleNetHttpTransport.newTrustedTransport()

            // Authenticate using Google Application Default Credentials.
            var credential: GoogleCredential = GoogleCredential.getApplicationDefault()
            if (credential.createScopedRequired()) {
                val scopes: MutableList<String> = ArrayList()
                // Set Google Cloud Storage scope to Full Control.
                scopes.add(ComputeScopes.DEVSTORAGE_FULL_CONTROL)
                // Set Google Compute Engine scope to Read-write.
                scopes.add(ComputeScopes.COMPUTE)
                credential = credential.createScoped(scopes)
            }

            // Create Compute Engine object for listing instances.
            val compute: Compute = Builder(httpTransport, JSON_FACTORY, credential)
                    .setApplicationName(APPLICATION_NAME)
                    .build()

            // List out instances
            printInstances(compute)
        } catch (e: IOException) {
            System.err.println(e.message)
        } catch (t: Throwable) {
            t.printStackTrace()
        }
        System.exit(1)
    }
    // [START list_instances]
    /**
     * Print available machine instances.
     *
     * @param compute The main API access point
     * @return `true` if the instance created by this sample app is in the list
     */
    @kotlin.Throws(IOException::class)
    fun printInstances(compute: Compute) {
        println("================== Listing Compute Engine Instances ==================")
        val instances: Compute.Instances.List = compute.instances().list(PROJECT_ID, ZONE_NAME)
        val list: InstanceList = instances.execute()
        if (list.getItems() == null) {
            println("No instances found. Sign in to the Google Developers Console and create "
                    + "an instance at: https://console.developers.google.com/")
        } else {
            for (instance in list.getItems()) {
                System.out.println(instance.toPrettyString())
            }
        }
    } // [END list_instances]
}